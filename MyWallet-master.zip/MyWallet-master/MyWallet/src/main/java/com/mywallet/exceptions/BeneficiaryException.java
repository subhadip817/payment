package com.mywallet.exceptions;

public class BeneficiaryException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BeneficiaryException() {
		super();
	}

	public BeneficiaryException(String message) {
		super(message);
	}

	
}
